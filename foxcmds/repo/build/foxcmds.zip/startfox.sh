clear
echo  ""
sleep 0.1
echo  ""
sleep 0.1
echo  ""
sleep 0.1
echo  ""
sleep 0.1
echo  "                                         /| "
sleep 0.1
echo  "                                        / | "
sleep 0.1
echo  "                                      _/  |__ "
sleep 0.1
echo  "                                   __/       \. "
sleep 0.1
echo  "                                  /          |"
sleep 0.1
echo  "                   ___            /           \___ "
sleep 0.1
echo  "                  /   \          |                \ "
sleep 0.1
echo  "                 |    \       __\             ___/ "
sleep 0.1
echo  "                 |    |     _/               \_"
sleep 0.1
echo  "                 |    |    /                   \__"
sleep 0.1
echo  "                 |    |   /                ____   \__"
sleep 0.1
echo  "                 |    |  /                /    \___  \."
sleep 0.1
echo  "                 |    |  |               /         \__|"
sleep 0.1
echo  "                 |    |  |              / "
sleep 0.1
echo  "                 |    |  |             /  "
sleep 0.1
echo  "                 |     \_|             |___ "
sleep 0.1
echo  "                 \                         | "
sleep 0.1
echo  "                  \______/\______________ __/ "
sleep 0.1
#
echo "
  |======  ______  \  /     ____    _      _    ____   _____
  |       /      \  \/     /    \  / \    / \  |    \ (____
  |====== |      |  /\     |      /   \  /   \ |    |      \.
  |       \______/ /  \    \____/ |    \/    | |____/ _____/"
#


sleep 1




                       

#read exit




exit



