#plugins. see syntax on the website.
#cd
if [ $cddir == "~" ]
	then
		cd $homedir
	else
		cd $cddir
	fi
#start of plugins	

if [ "$input" == plugindebug ]
then 
	echo cmdfnd=true >> $homedir/.foxcmds/plugins/cmdfnd.src
	#
	echo input=$input arg=$arg arg1=$arg1 arg2=$arg2 arg3=$arg3 arg4=$arg4
	echo homedir=$homedir name=$name cddir=$cddir
	
fi


#foxcmds subcommands
if [ "$input" == foxcmds ]
then
	echo cmdfnd=true >> $homedir/.foxcmds/plugins/cmdfnd.src
	#
	#info
	if [ "$arg" == info ]
	then
		echo fox-commands-promt
		echo current version : $cmdsver
		cat $homedir/.foxcmds/plugins.txt
	fi
	if [ "$arg" == restart ]
	then
		echo "break" >> $homedir/.foxcmds/plugins/cmdfnd.src
		clear
		$homedir/foxcmds
	fi
	if [ "$arg" == fox ]
	then
		/.vosjedev/foxcmds/startfox.sh
		read -n 1
	fi
	if [ "$arg" == history ]
	then
		if [ "$arg1" == view ]
		then
			cp $homedir/.foxcmds/history.txt $homedir/.foxcmds/historyview.txt 
			nano -v -R -m +-1 $homedir/.foxcmds/historyview.txt
			rm $homedir/.foxcmds/historyview.txt
			read -e -p "$name@foxpromt $cddirdis: " input arg arg1 arg2 arg3 arg4
		fi
		if [ "$arg1" == clear ]
		then
			rm $homedir/.foxcmds/history.txt
			touch $homedir/.foxcmds/history.txt
		fi
		if [ "$arg1" == '' ]
		then
		echo "use
view --- to view the log
clear -- to clear the log. this wil not delete the latest 5 commands in memory."
		fi
	fi
	if [ "$arg" == config ]
	then
		if [ "$arg1" == reload ]
		then
		echo "source $homedir/.foxcmds/config.cfg" >> $homedir/.foxcmds/plugins/cmdfnd.src
		fi
		if [ "$arg1" == edit ]
		then
		nano $homedir/.foxcmds/config.cfg
		echo use foxcmds config reload to apply changes.
		fi
		if [ "$arg1" == '' ]
		then
		echo "use
reload -- to reload the config
edit ---- to edit the config"
		fi
	fi
	#
	if [ "$arg" == '' ]
	then
		echo "possible arguments:
info
help
restart
history
config
"
	fi
	
fi
if [ "$input" == var ]
then
echo cmdfnd=true >> $homedir/.foxcmds/plugins/cmdfnd.src
#
echo "$arg=$arg1" >> $homedir/.foxcmds/plugins/cmdfnd.src
fi


#check-skipper plugin
if [ "$input" == cskip ]
then
echo cmdfnd=true >> $homedir/.foxcmds/plugins/cmdfnd.src
$arg $arg1 $arg2 $arg3 $arg4
fi

